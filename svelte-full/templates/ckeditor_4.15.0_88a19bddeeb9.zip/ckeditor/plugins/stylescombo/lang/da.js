﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'da', {
	label: 'Typografi',
	panelTitle: 'Formatering på stylesheet',
	panelTitle1: 'Blok typografi',
	panelTitle2: 'Inline typografi',
	panelTitle3: 'Objekt typografi'
} );
