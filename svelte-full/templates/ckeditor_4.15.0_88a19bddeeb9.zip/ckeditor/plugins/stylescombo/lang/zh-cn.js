﻿/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'zh-cn', {
	label: '样式',
	panelTitle: '样式',
	panelTitle1: '块级元素样式',
	panelTitle2: '内联元素样式',
	panelTitle3: '对象元素样式'
} );
